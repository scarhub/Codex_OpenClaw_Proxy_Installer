$names = @('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY')
Write-Host 'Current process environment:'
foreach ($name in $names) {
    $value = [Environment]::GetEnvironmentVariable($name, 'Process')
    Write-Host ("  {0} = {1}" -f $name, $(if ($value) { $value } else { '<not set>' }))
}
Write-Host ''
Write-Host 'Persistent user environment:'
foreach ($name in $names) {
    $value = [Environment]::GetEnvironmentVariable($name, 'User')
    Write-Host ("  {0} = {1}" -f $name, $(if ($value) { $value } else { '<not set>' }))
}
