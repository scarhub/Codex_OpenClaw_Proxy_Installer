param([string]$HostName = '', [int]$Port = 0)
$packageRoot = Split-Path -Parent $PSScriptRoot
$configPath = Join-Path $packageRoot 'config.ps1'
if (-not (Test-Path -LiteralPath $configPath)) { $configPath = Join-Path $packageRoot 'config.example.ps1' }
. $configPath
if ($HostName) { $ProxyHost = $HostName }
if ($Port -gt 0) { $ProxyPort = $Port }
if (Test-NetConnection -ComputerName $ProxyHost -Port $ProxyPort -InformationLevel Quiet -WarningAction SilentlyContinue) {
    Write-Host "[PASS] ${ProxyHost}:${ProxyPort} is listening."; exit 0
}
Write-Host "[FAIL] ${ProxyHost}:${ProxyPort} is unavailable."; exit 1
