[CmdletBinding()]
param([string]$OutputDirectory = '')

$ErrorActionPreference = 'Continue'
$packageRoot = Split-Path -Parent $PSScriptRoot
$configPath = Join-Path $packageRoot 'config.ps1'
if (-not (Test-Path -LiteralPath $configPath)) { $configPath = Join-Path $packageRoot 'config.example.ps1' }
. $configPath
if (-not $OutputDirectory) { $OutputDirectory = Join-Path $packageRoot 'Diagnostics' }
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$outFile = Join-Path $OutputDirectory "diagnostics-$stamp.txt"

function Add-Line([string]$Text) { Add-Content -LiteralPath $outFile -Value $Text -Encoding UTF8 }
Add-Line "OpenClaw/Codex proxy diagnostics - $(Get-Date -Format o)"
Add-Line "OS: $([Environment]::OSVersion.VersionString)"
Add-Line "Proxy endpoint: $ProxyUri"
Add-Line "Proxy listening: $([bool](Test-NetConnection -ComputerName $ProxyHost -Port $ProxyPort -InformationLevel Quiet -WarningAction SilentlyContinue))"
Add-Line "Gateway port listening: $([bool](Get-NetTCPConnection -LocalAddress '127.0.0.1' -LocalPort $GatewayPort -State Listen -ErrorAction SilentlyContinue))"
Add-Line ''
Add-Line 'User environment (safe proxy names only):'
foreach ($name in @('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY')) { Add-Line ("$name=$([Environment]::GetEnvironmentVariable($name,'User'))") }
Add-Line ''
Add-Line "gateway.cmd exists: $(Test-Path -LiteralPath $OpenClawGatewayCmd -PathType Leaf)"
if (Get-Command codex -ErrorAction SilentlyContinue) {
    $oldHome=$env:CODEX_HOME; $oldHttp=$env:HTTP_PROXY; $oldHttps=$env:HTTPS_PROXY; $oldNo=$env:NO_PROXY
    if ($CodexHome) { $env:CODEX_HOME=$CodexHome }
    $env:HTTP_PROXY=$ProxyUri; $env:HTTPS_PROXY=$ProxyUri; $env:NO_PROXY=$NoProxy
    $doctorText=& codex doctor --json 2>$null | Out-String
    $env:HTTP_PROXY=$oldHttp; $env:HTTPS_PROXY=$oldHttps; $env:NO_PROXY=$oldNo
    if ($oldHome) { $env:CODEX_HOME=$oldHome } else { Remove-Item Env:CODEX_HOME -ErrorAction SilentlyContinue }
    try {
        $d=$doctorText|ConvertFrom-Json; $w=$d.checks.'network.websocket_reachability'
        Add-Line "Codex WebSocket summary: $($w.summary)"
        Add-Line "Codex WebSocket handshake: $($w.details.'handshake result')"
    } catch { Add-Line 'Codex doctor: unavailable or unauthenticated' }
}
Add-Line 'Sensitive credentials and full prompts are intentionally excluded.'
Write-Host "[PASS] Diagnostics written to $outFile"
