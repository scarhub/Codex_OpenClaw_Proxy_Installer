[CmdletBinding()]
param([ValidateSet('start','stop','status')][string]$Command = 'status')

$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent $PSScriptRoot
$configPath = Join-Path $packageRoot 'config.ps1'
if (-not (Test-Path -LiteralPath $configPath)) { $configPath = Join-Path $packageRoot 'config.example.ps1' }
. $configPath

function Test-ProxyListener {
    [bool](Test-NetConnection -ComputerName $ProxyHost -Port $ProxyPort -InformationLevel Quiet -WarningAction SilentlyContinue)
}
function UserValue([string]$Name) {
    $value = [Environment]::GetEnvironmentVariable($Name, 'User')
    if ([string]::IsNullOrWhiteSpace($value)) { '<not set>' } else { $value }
}
function ShowStatus {
    Write-Host 'User-level proxy environment:'
    Write-Host ("  HTTP_PROXY  = {0}" -f (UserValue 'HTTP_PROXY'))
    Write-Host ("  HTTPS_PROXY = {0}" -f (UserValue 'HTTPS_PROXY'))
    Write-Host ("  NO_PROXY    = {0}" -f (UserValue 'NO_PROXY'))
    if (Test-ProxyListener) { Write-Host "Proxy listener: available (${ProxyHost}:${ProxyPort})" -ForegroundColor Green }
    else { Write-Host "Proxy listener: unavailable (${ProxyHost}:${ProxyPort})" -ForegroundColor Yellow }
    $settings = Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -ErrorAction SilentlyContinue
    Write-Host 'Windows system proxy (read-only):'
    Write-Host ("  ProxyEnable = {0}" -f $settings.ProxyEnable)
    Write-Host ("  ProxyServer = {0}" -f $(if ($settings.ProxyServer) { $settings.ProxyServer } else { '<not set>' }))
    Write-Host '  WinHTTP      = unchanged/read-only'
}
switch ($Command.ToLowerInvariant()) {
    'start' {
        if (-not (Test-ProxyListener)) { Write-Error "Proxy ${ProxyHost}:${ProxyPort} is not available. Please start the proxy application first."; exit 1 }
        [Environment]::SetEnvironmentVariable('HTTP_PROXY', $ProxyUri, 'User')
        [Environment]::SetEnvironmentVariable('HTTPS_PROXY', $ProxyUri, 'User')
        [Environment]::SetEnvironmentVariable('NO_PROXY', $NoProxy, 'User')
        Write-Host "User-level proxy variables enabled: $ProxyUri" -ForegroundColor Green
        Write-Host "NO_PROXY=$NoProxy"
        Write-Host 'Restart Codex GUI completely for the new environment to take effect.' -ForegroundColor Yellow
    }
    'stop' {
        foreach ($name in @('HTTP_PROXY','HTTPS_PROXY','NO_PROXY')) { [Environment]::SetEnvironmentVariable($name, $null, 'User') }
        Write-Host 'User-level proxy variables removed.' -ForegroundColor Green
        Write-Host 'Restart Codex GUI completely for the change to take effect.' -ForegroundColor Yellow
    }
    'status' { ShowStatus }
}
