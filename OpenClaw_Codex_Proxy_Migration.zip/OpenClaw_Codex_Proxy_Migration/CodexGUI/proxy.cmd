@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0proxy.ps1" %*
exit /b %errorlevel%
