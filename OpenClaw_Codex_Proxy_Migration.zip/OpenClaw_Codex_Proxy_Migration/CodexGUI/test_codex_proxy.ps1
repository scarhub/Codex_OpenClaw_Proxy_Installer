[CmdletBinding()]
param([switch]$SkipDoctor)

$ErrorActionPreference = 'Continue'
$packageRoot = Split-Path -Parent $PSScriptRoot
$configPath = Join-Path $packageRoot 'config.ps1'
if (-not (Test-Path -LiteralPath $configPath)) { $configPath = Join-Path $packageRoot 'config.example.ps1' }
. $configPath
function Result($state, $message) { Write-Host ("[{0}] {1}" -f $state, $message) }
$listener = [bool](Test-NetConnection -ComputerName $ProxyHost -Port $ProxyPort -InformationLevel Quiet -WarningAction SilentlyContinue)
if ($listener) { Result 'PASS' "Proxy ${ProxyHost}:${ProxyPort} is listening." } else { Result 'FAIL' "Proxy ${ProxyHost}:${ProxyPort} is unavailable." }
foreach ($name in @('HTTP_PROXY','HTTPS_PROXY','NO_PROXY')) {
    $value = [Environment]::GetEnvironmentVariable($name, 'User')
    if ($value) { Result 'PASS' "User $name is set." } else { Result 'WARN' "User $name is not set." }
}
if (-not $SkipDoctor -and (Get-Command codex -ErrorAction SilentlyContinue)) {
    $oldHome = $env:CODEX_HOME; $oldHttp = $env:HTTP_PROXY; $oldHttps = $env:HTTPS_PROXY; $oldNo = $env:NO_PROXY
    $env:HTTP_PROXY = [Environment]::GetEnvironmentVariable('HTTP_PROXY','User')
    $env:HTTPS_PROXY = [Environment]::GetEnvironmentVariable('HTTPS_PROXY','User')
    $env:NO_PROXY = [Environment]::GetEnvironmentVariable('NO_PROXY','User')
    if ($CodexHome) { $env:CODEX_HOME = $CodexHome }
    $text = (& codex doctor --json 2>$null | Out-String)
    if ($oldHome) { $env:CODEX_HOME = $oldHome } else { Remove-Item Env:CODEX_HOME -ErrorAction SilentlyContinue }
    $env:HTTP_PROXY=$oldHttp; $env:HTTPS_PROXY=$oldHttps; $env:NO_PROXY=$oldNo
    try {
        $doctor = $text | ConvertFrom-Json
        $ws = $doctor.checks.'network.websocket_reachability'
        $handshake = $ws.details.'handshake result'
        if ($ws.summary -like '*succeeded*' -or $handshake -like '*101*') { Result 'PASS' "WebSocket: $($ws.summary); $handshake" }
        else { Result 'WARN' "WebSocket doctor result: $($ws.summary)" }
    } catch { Result 'WARN' 'Codex doctor output unavailable or unauthenticated.' }
}
