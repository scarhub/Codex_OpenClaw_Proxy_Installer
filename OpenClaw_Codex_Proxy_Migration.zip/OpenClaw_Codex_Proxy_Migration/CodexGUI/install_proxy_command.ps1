[CmdletBinding(SupportsShouldProcess = $true)]
param([switch]$DryRun)

$ErrorActionPreference = 'Stop'
$codexGuiDir = $PSScriptRoot
$userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
$entries = @($userPath -split ';' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
$exists = $entries | Where-Object { $_.TrimEnd('\') -ieq $codexGuiDir.TrimEnd('\') }
if ($exists) { Write-Host "[PASS] User PATH already contains $codexGuiDir"; exit 0 }
if ($DryRun) { Write-Host "[DRY-RUN] Would append $codexGuiDir to user PATH." -ForegroundColor Yellow; exit 0 }
$newPath = (($entries + $codexGuiDir) -join ';')
[Environment]::SetEnvironmentVariable('Path', $newPath, 'User')
Write-Host "[PASS] Added CodexGUI directory to user PATH: $codexGuiDir" -ForegroundColor Green
