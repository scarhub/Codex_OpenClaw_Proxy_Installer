# Copy this file to config.ps1 on the target Windows host and adjust only
# machine-specific values. Never put API keys, OAuth tokens, cookies, or
# other credentials in this file.
$ProxyHost = '127.0.0.1'
$ProxyPort = 10090
$GatewayPort = 18789
$TaskName = 'OpenClaw Gateway'

$PackageRoot = $PSScriptRoot
$ProxyUri = "http://$ProxyHost`:$ProxyPort"
$NoProxy = '127.0.0.1,localhost,::1'
$OpenClawGatewayCmd = Join-Path $env:USERPROFILE '.openclaw\gateway.cmd'

# Optional: set this to the Codex HOME used by a specific OpenClaw agent.
# Leave empty to use the current process/default Codex HOME for diagnostics.
$CodexHome = ''
