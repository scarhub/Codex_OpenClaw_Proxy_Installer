# OpenClaw / Codex Proxy Migration

本包把已验证的 Windows 代理修复方案迁移到其他主机。它不修改 Codex、OpenClaw 或 provider，不关闭 Responses WebSocket，也不改变 Windows“设置→网络和 Internet→代理”或 WinHTTP。

## 问题与原理

Codex 默认优先使用 Responses WebSocket。若 Gateway/Codex 子进程没有继承本机 HTTP 代理，连接会超时、重试多次，再 fallback 到 HTTP，表现为约 116 秒首 token 延迟。让进程继承 `HTTP_PROXY`、`HTTPS_PROXY` 和 `NO_PROXY` 后，WebSocket 可通过本地代理完成 `HTTP 101 Switching Protocols`，实测 TTFT 约 6～7 秒。

不能简单关闭 WebSocket：那会改变传输协议，失去 Codex 的正常实时流式路径；正确做法是让 WebSocket 使用可用代理。

## 两套独立控制

- OpenClaw：Task Scheduler 直接调用 `OpenClaw\start_openclaw_gateway.ps1`，每次启动时只给 Gateway 及其子进程注入代理。
- Codex GUI：`CodexGUI\proxy.cmd start|stop|status` 管理 Windows 用户级持久环境变量。

因此 `proxy stop` 不会影响 OpenClaw，OpenClaw 仍使用自己的启动脚本；两者互不依赖。

## 新主机安装

1. 安装并启动本地 HTTP 代理，确认端口（默认 `127.0.0.1:10090`）。
2. 安装并登录 Codex GUI；安装并登录 OpenClaw。认证必须在新主机重新完成，不要复制旧主机的 `.codex` 或 `.openclaw` 认证目录。
3. 将 `config.example.ps1` 复制为 `config.ps1`，按新主机修改 `$ProxyHost`、`$ProxyPort`、`$GatewayPort`；不要写入任何凭据。
4. 运行 `OpenClaw\start_openclaw_gateway.ps1 -CheckOnly` 和 `Diagnostics\check_proxy_port.ps1`。
5. 运行 `OpenClaw\install_openclaw_task.ps1`。脚本会先把现有 `OpenClaw Gateway` 任务 XML 备份到 `Backup`，只替换 Action；找不到任务时不会凭空创建。
6. 运行 `CodexGUI\install_proxy_command.ps1`（只追加用户 PATH，幂等）。
7. 执行 `proxy start`，完全退出并重新启动 Codex GUI。已有 GUI 进程不会自动获得新环境变量。
8. 使用 `OpenClaw\test_openclaw_proxy.ps1` 和 `CodexGUI\test_codex_proxy.ps1` 验证。

成功标志是 `Responses WebSocket handshake succeeded`、`HTTP 101 Switching Protocols`，且 Codex/OpenClaw 日志中 retry 与 HTTP fallback 为 0。

## 回滚

运行 `OpenClaw\uninstall_openclaw_task.ps1`，它默认选择 `Backup` 中最新的安装前 XML；没有备份时会拒绝操作。`proxy stop` 删除三个用户级变量。系统代理、WinHTTP 和源码均不被回滚脚本修改。

## 常见故障

- 代理端口不可用：先启动代理软件或修正 `config.ps1`，脚本会停止而不会启动 Gateway。
- WebSocket 仍超时：确认 Task Scheduler Action 是 PowerShell 迁移脚本，检查 `Logs\openclaw-gateway-proxy.log` 和 `logs_2.sqlite`，不要先改 reasoning/provider。
- `codex doctor` 在隔离 OpenClaw HOME 显示未认证：这通常只是独立 doctor 没有 OpenClaw 运行时注入的 ChatGPT 认证；以实际 Agent runtime 日志中的 WebSocket 101 为准，并在新主机正常登录。
- `proxy start` 后 GUI 没变化：完全退出 Codex GUI 及后台进程，再重新启动。

所有诊断工具只输出代理/网络状态，不收集 OAuth token、Cookie、API key、密码、微信凭据或完整聊天记录。
