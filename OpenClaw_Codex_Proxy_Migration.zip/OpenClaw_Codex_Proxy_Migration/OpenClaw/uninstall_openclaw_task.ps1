[CmdletBinding()]
param(
    [switch]$DryRun,
    [string]$BackupFile
)

$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $packageRoot 'config.example.ps1')
$backupDir = Join-Path $packageRoot 'Backup'
if (-not $BackupFile) {
    $latest = Get-ChildItem -LiteralPath $backupDir -Filter 'OpenClaw_Gateway.before_*.xml' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($latest) { $BackupFile = $latest.FullName }
}
if (-not $BackupFile -or -not (Test-Path -LiteralPath $BackupFile -PathType Leaf)) {
    if ($DryRun) { Write-Host '[DRY-RUN] No backup XML exists yet; rollback would refuse to modify the task.' -ForegroundColor Yellow; exit 0 }
    throw 'No Task Scheduler backup XML was found; refusing to invent an original task.'
}

Write-Host "Restore source: $BackupFile"
if ($DryRun) { Write-Host '[DRY-RUN] Would restore the Task Scheduler XML.' -ForegroundColor Yellow; exit 0 }
$xml = Get-Content -LiteralPath $BackupFile -Raw
Register-ScheduledTask -TaskName $TaskName -Xml $xml -Force | Out-Null
Write-Host "[PASS] Restored Task Scheduler task '$TaskName'." -ForegroundColor Green
