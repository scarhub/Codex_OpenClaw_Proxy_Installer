[CmdletBinding()]
param([switch]$SkipDoctor)

$ErrorActionPreference = 'Continue'
$packageRoot = Split-Path -Parent $PSScriptRoot
$configPath = Join-Path $packageRoot 'config.ps1'
if (-not (Test-Path -LiteralPath $configPath)) { $configPath = Join-Path $packageRoot 'config.example.ps1' }
. $configPath

function Result($state, $message) { Write-Host ("[{0}] {1}" -f $state, $message) }
$proxyOk = [bool](Test-NetConnection -ComputerName $ProxyHost -Port $ProxyPort -InformationLevel Quiet -WarningAction SilentlyContinue)
if ($proxyOk) { Result 'PASS' "Proxy ${ProxyHost}:${ProxyPort} is listening." } else { Result 'FAIL' "Proxy ${ProxyHost}:${ProxyPort} is unavailable." }
if (Test-Path -LiteralPath $OpenClawGatewayCmd -PathType Leaf) { Result 'PASS' "gateway.cmd exists: $OpenClawGatewayCmd" } else { Result 'FAIL' "gateway.cmd missing: $OpenClawGatewayCmd" }
$gatewayListening = Get-NetTCPConnection -LocalAddress '127.0.0.1' -LocalPort $GatewayPort -State Listen -ErrorAction SilentlyContinue
if ($gatewayListening) { Result 'PASS' "Gateway is listening on 127.0.0.1:$GatewayPort." } else { Result 'WARN' "Gateway is not currently listening on 127.0.0.1:$GatewayPort." }

if (-not $SkipDoctor -and (Get-Command codex -ErrorAction SilentlyContinue)) {
    $oldHome = $env:CODEX_HOME
    if ($CodexHome) { $env:CODEX_HOME = $CodexHome }
    $doctorText = (& codex doctor --json 2>$null | Out-String)
    if ($oldHome) { $env:CODEX_HOME = $oldHome } else { Remove-Item Env:CODEX_HOME -ErrorAction SilentlyContinue }
    try {
        $doctor = $doctorText | ConvertFrom-Json
        $ws = $doctor.checks.'network.websocket_reachability'
        $summary = $ws.summary
        $handshake = $ws.details.'handshake result'
        if ($summary -like '*succeeded*' -or $handshake -like '*101*') { Result 'PASS' "Codex WebSocket: $summary ($handshake)" }
        else { Result 'WARN' "Codex WebSocket doctor result: $summary" }
    } catch { Result 'WARN' 'Codex doctor output was unavailable or not authenticated.' }
}
elseif (-not $SkipDoctor) { Result 'WARN' 'codex command was not found; skipping doctor.' }
