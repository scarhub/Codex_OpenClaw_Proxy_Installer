[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [switch]$DryRun,
    [string]$TaskName
)

$ErrorActionPreference = 'Stop'
$requestedTaskName = $TaskName
$packageRoot = Split-Path -Parent $PSScriptRoot
$configPath = Join-Path $packageRoot 'config.ps1'
if (-not (Test-Path -LiteralPath $configPath)) { $configPath = Join-Path $packageRoot 'config.example.ps1' }
. $configPath
$effectiveTaskName = if ($requestedTaskName) { $requestedTaskName } else { $TaskName }
$gatewayScript = Join-Path $packageRoot 'OpenClaw\start_openclaw_gateway.ps1'
$backupDir = Join-Path $packageRoot 'Backup'

if (-not (Test-Path -LiteralPath $gatewayScript)) { throw "Missing gateway script: $gatewayScript" }
$task = Get-ScheduledTask -TaskName $effectiveTaskName -TaskPath '\' -ErrorAction SilentlyContinue
if (-not $task) { throw "Scheduled Task '$effectiveTaskName' was not found. Create it with OpenClaw first; no task was changed." }

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backupPath = Join-Path $backupDir "OpenClaw_Gateway.before_$stamp.xml"
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

Write-Host "Existing task: $effectiveTaskName"
Write-Host "New action: powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$gatewayScript`""
Write-Host "WorkingDirectory: $packageRoot"
if ($DryRun) {
    Write-Host '[DRY-RUN] Would export XML and replace only the task Action.' -ForegroundColor Yellow
    exit 0
}

Export-ScheduledTask -TaskName $effectiveTaskName -TaskPath '\' | Out-File -LiteralPath $backupPath -Encoding Unicode
$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$gatewayScript`"" -WorkingDirectory $packageRoot
Set-ScheduledTask -TaskName $effectiveTaskName -TaskPath '\' -Action $action | Out-Null
Write-Host "[PASS] Task Action updated; backup: $backupPath" -ForegroundColor Green
