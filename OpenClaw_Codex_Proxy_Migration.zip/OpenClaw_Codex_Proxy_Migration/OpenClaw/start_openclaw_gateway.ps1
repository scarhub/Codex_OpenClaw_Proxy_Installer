[CmdletBinding()]
param([switch]$CheckOnly)

$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent $PSScriptRoot
$configPath = Join-Path $packageRoot 'config.ps1'
if (-not (Test-Path -LiteralPath $configPath)) { $configPath = Join-Path $packageRoot 'config.example.ps1' }
. $configPath

$logDir = Join-Path $packageRoot 'Logs'
$logFile = Join-Path $logDir 'openclaw-gateway-proxy.log'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null

function Write-GatewayLog {
    param([Parameter(Mandatory = $true)][string]$Message)
    $line = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $Message"
    Add-Content -LiteralPath $logFile -Value $line -Encoding UTF8
    Write-Host $line
}

try {
    $available = [bool](Test-NetConnection -ComputerName $ProxyHost -Port $ProxyPort -InformationLevel Quiet -WarningAction SilentlyContinue)
    if (-not $available) {
        $message = "[ERROR] Proxy ${ProxyHost}:${ProxyPort} is not available. Please start the proxy application first."
        Write-GatewayLog $message
        if (-not $CheckOnly) { Write-Error $message }
        exit 1
    }

    if (-not (Test-Path -LiteralPath $OpenClawGatewayCmd -PathType Leaf)) {
        $message = "[ERROR] OpenClaw Gateway launcher not found: $OpenClawGatewayCmd"
        Write-GatewayLog $message
        if (-not $CheckOnly) { Write-Error $message }
        exit 1
    }

    if ($CheckOnly) {
        Write-GatewayLog "[PASS] Proxy available at $ProxyUri and gateway.cmd exists."
        exit 0
    }

    $env:HTTP_PROXY = $ProxyUri
    $env:HTTPS_PROXY = $ProxyUri
    $env:NO_PROXY = $NoProxy
    Write-GatewayLog "Proxy available at $ProxyUri; HTTP_PROXY=$env:HTTP_PROXY; HTTPS_PROXY=$env:HTTPS_PROXY; NO_PROXY=$env:NO_PROXY."

    & $OpenClawGatewayCmd
    $exitCode = $LASTEXITCODE
    Write-GatewayLog "OpenClaw Gateway launcher exited with code $exitCode."
    exit $exitCode
}
catch {
    $message = "[ERROR] Failed to start OpenClaw Gateway: $($_.Exception.Message)"
    Write-GatewayLog $message
    if (-not $CheckOnly) { Write-Error $message }
    exit 1
}
